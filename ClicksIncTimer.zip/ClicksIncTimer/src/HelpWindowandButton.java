
import processing.core.PApplet;

public class HelpWindowandButton extends Button {
    private boolean help;

    public HelpWindowandButton(float x, float y, float buttonSides, PApplet sketch) {
        super(x, y, buttonSides, sketch,true);
        help = false;

    }



    public boolean getHelpBool() {
        return help;
    }

    public void flipHelp() {
        help = !help;
    }

    public void renderExtras() {
        if (!help) {
            getSketch().rect(getX(), getY(), getWidth(), getWidth(), 7);
            getSketch().fill(0, 0, 0);
            getSketch().textSize((getWidth() + getWidth()) / 8);
            getSketch().text("HELP", getX() + getWidth() / 2, getY() + 3 * getWidth() / 4);
            getSketch().textSize((getWidth() + getWidth())/ 4);
            getSketch().text("?", getX() + (getWidth() / 2), getY() + (getWidth() / 3));
            getSketch().fill(255, 255, 255);
        } else {
            getSketch().fill(255, 255, 255);
            getSketch().rect(0, 0, getSketch().width, getSketch().height);
            getSketch().fill(0, 0, 0);
            getSketch().textSize(getSketch().width / 20);
            getSketch().text("Clicks Inc Timer help page", getSketch().width / 2, getSketch().height / 16);
            getSketch().textSize(getSketch().width / 60);
            getSketch().text("The help button toggles this page and the timer.", getSketch().width / 4, getSketch().height / 8);
            getSketch().text("The inspection button (eye symbol) toggles inspection.", 3 * getSketch().width / 4, getSketch().height / 8);
            getSketch().text("Inspection is 15 seconds in which the cuber gets to inspect the cube before the solve starts.", getSketch().width / 2, 3 * getSketch().height / 16);
            getSketch().text("Press space to operate the timer and see how fast you can solve the cube.", getSketch().width / 2, getSketch().height / 2);
            getSketch().text("Use the Clear Times button to clear the currently recorded times from the timer.", getSketch().width / 2, 5 * getSketch().height / 8);
            //Button
            getSketch().fill(51);
            getSketch().rect(getX(),getY(), getWidth(), getWidth(), 7);
            getSketch().fill(255, 255, 255);
            getSketch().textSize(getWidth() / 4);
            getSketch().text("HELP", getX() + getWidth() / 2, getY() + 7 * getWidth() / 8);
            getSketch().textSize(getWidth() / 2);
            getSketch().text("?", getX() + (getWidth() / 2), getY() + (getWidth() / 2));
            //Pseudo-Inspection Button for demo purposes.
            getSketch().fill(255, 255, 255);
            getSketch().rect(getSketch().width - getWidth(), 0, getWidth(), getWidth(), 7);
            getSketch().ellipse(getSketch().width - (getWidth() / 2), getWidth() / 2, getWidth(), getWidth() / 2);
            getSketch().fill(0, 0, 0);
            getSketch().ellipse(getSketch().width - (getWidth() / 2), getWidth() / 2, getWidth() / 2, getWidth() / 2);
            getSketch().fill(255, 255, 255);

        }
    }


}

/*
June 8, 2018:
Wierd thing spotted: setting WindowWidth and WindowHeight to sketch.getWidth and sketch.getWidth results in 100,100 because sketch's settings were not declared in the Main class.
For this reason, I used sketch.width and sketch.height rather than my own variables
It turns out it's also more flexible if width and height are changed.

At some point thet page will run out of room so I need to add front and back buttons later
as well as a "page" counter int and pages.
 */