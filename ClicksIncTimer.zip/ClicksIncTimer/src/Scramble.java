import processing.core.PApplet;
public class Scramble {
    //private int ScrambleType; 3 for 3x3x3, 4 for 4x4x4, etc?
    private static String[] moves3 = {" F", " U", " R", " B", " D", " L"," F2", " U2", " R2", " B2", " D2", " L2"," F\'", " U\'", " R\'", " B\'", " D\'", " L\'"}; //3x3 moves
    private static String[] moves2 = {" F", " U", " R", " F\'", " U\'", " R\'", " F2", " U2", " R2"}; //2x2 moves
    private static String[] moves45 = {" F", " U", " R", " B", " D", " L"," F2", " U2", " R2", " B2", " D2", " L2"," F\'", " U\'", " R\'", " B\'", " D\'", " L\'", //index = 17
            " Fw", " Uw", " Rw", " Bw", " Dw", " Lw", " Fw2", " Uw2", " Rw2", " Bw2", " Dw2", " Lw2"," Fw\'", " Uw\'", " Rw\'", " Bw\'", " Dw\'", " Lw\'"}; //usable for 4x4 and 5x5 because repetition validation is the same and same moves


    private String Scramble = "";
    private int prevA;
    private int doublePrevA;
    private int a;


    public enum Puzzle{
        TWO,THREE,FOUR,FIVE,SIX,SEVEN,
    }
    private Puzzle puzzle = Puzzle.THREE;//This is default, can be changed

    private float x;
    private float y;
    private PApplet sketch;
    private Button ScrambleTypeButton;


    public Button getScrambleTypeButton(){
        return ScrambleTypeButton;
    }
    public void setScramble(String Scramble) {
        this.Scramble = Scramble;
    }
    public String getScramble(){
        return Scramble;
    }
    public Scramble(PApplet sketch, float x, float y, Puzzle puzzle, float ScrambleButtonX, float ScrambleButtonY, float ScrambleButtonWidth, float ScrambleButtonHeight){
        this.x = x;
        this.y = y;
        this.sketch = sketch;
        this.ScrambleTypeButton = new Button(ScrambleButtonX,ScrambleButtonY,ScrambleButtonWidth,ScrambleButtonHeight,sketch,true);
        Scramble = makeScramble();

    }
    
    
    
    public String makeScramble(){
        Scramble = "";
        switch(puzzle){
            case TWO:
                for(int i = 1; i <= 9; i++){
                    a = roll(9);
                    if(i>1){
                        if(repVal(a,puzzle)){
                            i--;
                        }else{
                            Scramble += moves2[a];
                            prevA = a;
                        }
                    }else{
                        Scramble += moves2[a];
                        prevA = a;
                    }
                }
                return Scramble;
            case THREE:
                //loop to 20
                //roll 1-18
                for(int i=1;i<=20;i++){
                    a=roll(18);
                    if(i>1){
                        if(repVal(a,puzzle)){
                            i--; //setback the loop
                        } else {
                            Scramble += moves3[a];
                            doublePrevA = prevA;
                            prevA = a;

                        }
                    }else{
                        Scramble+=moves3[a];
                        doublePrevA = prevA;
                        prevA = a;
                    }
                    //doublePrevA = prevA;
                    //prevA = a;

                }
                return Scramble;
            case FOUR:
                for(int i = 1; i <= 40; i++){
                    a = roll(36);
                    if(i>1){
                        if(repVal(a,puzzle)){
                            i--;
                        }else{
                            Scramble+=moves45[a];
                            doublePrevA = prevA;
                            prevA = a;
                        }
                        //repval 4
                    }else{
                        Scramble+=moves45[a];
                        doublePrevA = prevA;
                        prevA = a;
                    }
                }
                return Scramble;
            case FIVE:
                for(int i = 1; i <= 60; i++){
                    a = roll(36);
                    if(i>1){
                        if(repVal(a,puzzle)){
                            i--;
                        }else{
                            Scramble+=moves45[a];
                            doublePrevA = prevA;
                            prevA = a;
                        }
                        //repval 4
                    }else{
                        Scramble+=moves45[a];
                        doublePrevA = prevA;
                        prevA = a;
                    }
                }
                return Scramble;
        }
        return "ERROR";
    }
    private static int roll(int cap){
        int roll = (int)(Math.random()*cap);
        if(roll==cap){
            return roll(cap);
        }
        return roll;
    }

    private boolean repVal(int thismoveID, Puzzle p){
        switch(p){
            case TWO:
                if(prevA % 3 == thismoveID % 3){
                    return true;
                }
                return false;
            case THREE:
                if(prevA % 6 == thismoveID % 6){
                    return true;
                }else if(((((prevA % 6) + 3) % 6) == (thismoveID % 6)) && ((doublePrevA % 6) == (thismoveID % 6))){
                    return true;
                }
                return false;
            case FOUR:
                if(prevA % 6 == thismoveID % 6){
                    if((thismoveID > 17 && prevA > 17) || (thismoveID < 18 && prevA < 18)){//R (R) and Rw (Rw)
                        return true;
                    }
                    if(thismoveID > 17 && doublePrevA > 17){ //Rw R Rw
                        return true;
                    }else if(thismoveID < 18 && doublePrevA < 18){ //R Rw R
                        return true;
                    }
                }
                if(((prevA % 6) + 3) % 6 == thismoveID % 6){
                    if(thismoveID > 17 && prevA > 17){
                        return true;
                    }else if(thismoveID % 6 == doublePrevA % 6) {
                        if (doublePrevA < 18 && thismoveID < 18) {//R L R and R Lw R
                            return true;
                        } else if (doublePrevA > 17 && thismoveID > 17) {//Rw L Rw
                            return true;
                        }
                    }
                }
                return false;
            case FIVE:
                if(prevA % 6 == thismoveID % 6 && (thismoveID < 18 && prevA < 18 || thismoveID > 17 && prevA > 17)){
                    return true;
                }else if(((((prevA % 6) + 3) % 6) == (thismoveID % 6)) && ((doublePrevA % 6) == (thismoveID % 6))){ //R(w) L(w) R(w)
                    if(doublePrevA > 17 && thismoveID > 17 || doublePrevA < 18 && thismoveID < 18){ // R () R or Rw () Rw
                        return true;
                    }
                    return false;
                }
                return false;
            default:
                return false;
        }
    }

    public void incrementScrambleType() {
        switch(puzzle){
            case TWO:
                puzzle = Puzzle.THREE;
                break;
            case THREE:
                puzzle = Puzzle.FOUR;
                break;
            case FOUR:
                puzzle = Puzzle.FIVE;
                break;
            case FIVE:
                puzzle = Puzzle.TWO;
                break;
        }
    }
    private String getScrambleTypeString(){
        switch(puzzle){
            case TWO:
                return "2x2";
            case THREE:
                return "3x3";
            case FOUR:
                return "4x4";
            case FIVE:
                return "5x5";
            case SIX:
                return "6x6";
            case SEVEN:
                return "7x7";
        }
        return "ERROR";
    }
    private static String formatScrambleText(String scr){
        if(scr.length() <= 55){
            return scr;
        }
        for(int i = 54; i < scr.length(); i++){
            if (scr.charAt(i) == ' ') {
                return scr.substring(0, i-1) + "\n" + formatScrambleText(scr.substring(i, scr.length()-1));
            }
        }
       return scr;
        //This should never throw given our scramble sequences so it's like an appendix
    }
    private static short numNewLinesFound(String scr){
        short count = 0;
        for(int i = 0; i < scr.length(); i++){
            if(scr.charAt(i) == '\n'){
                count++;
            }
        }
        return count;
    }


    public void render(){
        ScrambleTypeButton.render();
        sketch.textSize(ScrambleTypeButton.getHeight() * 7 / 8);
        sketch.fill(0,0,0);
        sketch.text(getScrambleTypeString(), ScrambleTypeButton.getX() + (ScrambleTypeButton.getWidth() / 2), ScrambleTypeButton.getY() + (ScrambleTypeButton.getHeight() / 2));
        sketch.textSize(sketch.width/40);
        sketch.fill(255,255,255);
        sketch.text(formatScrambleText(Scramble), x,y + (numNewLinesFound(formatScrambleText(Scramble)) * sketch.height / 32));
    }
}
