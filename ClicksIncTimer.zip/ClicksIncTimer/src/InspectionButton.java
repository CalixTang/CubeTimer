import processing.core.PApplet;
public class InspectionButton extends Button{

    private boolean inspectionBool = true;

    public InspectionButton(float x, float y, float inspectButtonSides, PApplet sketch) {
        super(x,y,inspectButtonSides,sketch,true);
    }

    public void flipInspectionButtonBool() {
        this.inspectionBool = !this.inspectionBool;
    }
    public void renderExtras(){
        if(inspectionBool) {
            getSketch().ellipse((getX() + (getWidth() / 2)), (getY() + (getHeight() / 2)),getWidth(), getHeight() / 2); //Eye outline
            getSketch().fill(0, 0, 0);
            getSketch().ellipse((getX() + (getWidth()/ 2)), (getY() + (getHeight() / 2)), getWidth()/ 2, getHeight() / 2); //pupil/iris
            getSketch().fill(255, 255, 255);
        }
        else{
            getSketch().fill(0,0,0);
            getSketch().ellipse(getX() + getWidth()/2,getY() + getHeight()/2,3*getWidth()/4,getHeight()/6);
            getSketch().fill(255,255,255);
        }
    }
}
