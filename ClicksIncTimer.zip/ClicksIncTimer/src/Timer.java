import processing.core.PApplet;

import processing.core.PConstants;
import java.util.Scanner;

//import Time.Penalty;

import java.io.*;
public class Timer {

    private long startTime;
    private long endTime;
    private byte status;
    private float x;
    private float y;
    private String text;
    private PApplet sketch;
    private boolean inspection;
    private long inspectStartTime;
    private int inspectionTimeRemaining;
    private Time.Penalty penalty;
    private Scanner s;
    
    /** Reader and writer will read/write from timelist.txt with the following format per line:
     * 
     * (Time Double), (Time String), (Penalty int), (Scramble)
     * pen int: 0 ok 1 +2 2 DNF
     */

    /*
    Statuses: (inspection = false)
    Unused and ready = 0
    Being held down to start = 1
    Being let go of to start =2
    Pressed to end = 3

    Inspection = true:
    Ready = 0
    Held down for inspection = 1
    Let go for inspection and during inspection = 2
    Being held down to start timing = 3
    Timing and let go of for timing = 4
    pressed to end = 5



    7 -> This is a placeholder value so that we can immediately stop the timer when you press it.
    It cannot be even otherwise it will not work out well with the %2 operator in keyPressed in main().

    Penalty:
    0 -> no penalty
    1 -> +2
    2 -> DNF
     */
    public void setText(String text){ //Dont use if you dont have to
        this.text = text;
    }
    public String getText(){
        return this.text;
    }
    public long getStartTime(){
        return this.startTime;
    }
    public long getEndTime(){
        return this.endTime;
    }
    public int getStatus(){
        return this.status;
    }
    public Timer(PApplet sketch, float x, float y, boolean inspection){
        this.inspectionTimeRemaining = 0;
        this.inspectStartTime = 0;
        this.sketch = sketch;
        this.x = x;
        this.y = y;
        this.startTime = 0;
        this.endTime = 0;
        this.status = 0;
        this.text = "0.000";
        this.inspection = inspection;
        this.penalty = Time.Penalty.OK;
       
        
    }
    public short getPenalty(){
        switch(this.penalty) {
        case OK:
        	return 0;
        case P2:
        	return 1;
        case DNF:
        	return 2;
        default:
        	return -1; 
        }
        
    }
    //start Timer
    private void startTime(){
        startTime = System.currentTimeMillis();
    }
    //end Timer
    private void endTime(){
        endTime = System.currentTimeMillis();
    }
    //get elapsed time
    public String returnTime(long endTime, long startTime){
        return TrimTime(Double.toString((double)(endTime-startTime)/1000));
    }
    public static String TrimTime(String time){
        if(time.equals("DNF")){ //dumb solution but meh
            return time;
        }
        //Trims to two decimal places
        if((time.length()-time.indexOf('.') == 3)) {
            return time;
        }else if(time.length()-time.indexOf('.')<3 && time.indexOf('.') > 0){
            while((time.length()-time.indexOf('.')<3)) {
                time += "0";
            }
        }else if(time.indexOf('.') == -1){
            return time + ".00";
        }else {
            //Thus it is longer and shall be trimmed.
            return time.substring(0,time.indexOf('.')+3);
        }
        return time;
    }
    public static String PadTime(String time){
        if(time.indexOf('.') == 1){
            return "0" + time;
        }
        return time;
    }

    //reset Times
    public void reset(){
        startTime = 0;
        endTime = 0;
        status = 0;
        inspectStartTime = 0;
    }
    //inspection?
    public boolean getInspectionBool(){
        return inspection;
    }
    public void flipInspection(){
        inspection=!inspection;
    }
    private void startInspectionTime(){
        inspectStartTime = System.currentTimeMillis();
    }
    private String returnTimeLeftInspection(){
        inspectionTimeRemaining = 15-(int)((System.currentTimeMillis()-inspectStartTime)/1000);
        if(inspectionTimeRemaining >= 1) {
            return Integer.toString(inspectionTimeRemaining);
        } else if(inspectionTimeRemaining > -1){
            this.penalty = Time.Penalty.P2;
            return "+2";
        } else { //This is sufficient because inspectionTimeRemaining will only decrease.
            this.penalty = Time.Penalty.DNF;
            return "DNF";
        }
    }
    private void setTextColor(){
        if(inspection){
            switch(this.status){
                case 0:
                    sketch.fill(255,255,255);
                    break;
                case 1:
                    sketch.fill(0,255,0);
                    break;
                case 2:
                    sketch.fill(255,255,255);
                    break;
                case 3:
                    sketch.fill(0,255,0);
                    break;
                case 4:
                    sketch.fill(255,255,255);
                    break;
                case 5:
                    sketch.fill(255,0,0);
                    break;
                case 7:
                    sketch.fill(255,0,0);
            }
        }else{
            switch(this.status){
                case 0:
                    sketch.fill(255,255,255);
                    break;
                case 1:
                    sketch.fill(0,255,0);
                    break;
                case 2:
                    sketch.fill(255,255,255);
                    break;
                case 3:
                    sketch.fill(255,0,0);
                    break;
                case 7:
                    sketch.fill(255,0,0);
                    break;
            }
        }
    }

    //Warning: This method will update status and return the value of this.status from BEFORE THE UPDATE
    public int statusUpdate() {
        if (this.inspection) {
            if(this.status==0) {
                this.status++;
                this.text = "ready";
                this.penalty = Time.Penalty.OK;
                return 0;
            }else if(this.status == 1){
                this.status++;
                this.startInspectionTime();
                return 1;
            }else if(this.status == 2){
                this.status++;
                return 2;
            }else if(this.status == 3){
                this.status++;
                this.startTime();
                return 3;
            }else if(this.status == 4){
                this.status++;
                this.endTime();
                this.text = this.returnTime(this.getEndTime(), this.getStartTime());
                return 4;
            }else if(this.status == 5){
                this.status = 7;
                return 5;
            }else if(this.status == 7){
                this.reset();
                return 7;
            }
        } else {
            if(this.status == 0) {
                this.status++;
                this.text = "ready";
                this.penalty = Time.Penalty.OK;
                return 0;
            }else if(this.status == 1) {
                this.status++;
                this.startTime();
                return 1;
            }else if(this.status == 2) {
                this.status++;
                this.endTime();
                this.text = this.returnTime(this.getEndTime(), this.getStartTime());
                return 2;
            }else if(this.status == 3) {
                this.status = 7;
                return 3;
            }else if(this.status == 7){
                this.reset();
                return 7;
            }
        }
        return -1;
    }
    public String returnText(String text) {
        endTime = System.currentTimeMillis();
        if ((status == 2 || status ==3) && inspection) {
            //Inspecting time
            return returnTimeLeftInspection();
        }else if ((status == 4 && inspection) || (status == 2 && !inspection) || (status == 5 && inspection) || (status == 3 && !inspection)) {
            double time = Double.parseDouble(returnTime(endTime,startTime));
            if (time > 60) {
                return Integer.toString((int) (time / 60)) + ":" + PadTime(TrimTime(Double.toString(time % 60)));
            }
            return returnTime(endTime, startTime);
        }
        return text;
    }
    
    
    
    //GUI stuff
    public void render(){
        //No Inspection

        text = returnText(text);
        this.setTextColor();
        sketch.textSize(sketch.width/10);
        sketch.text(text, x, y);

    }
    
   
    
    
 
}
