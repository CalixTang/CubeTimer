import processing.awt.PSurfaceAWT;
import processing.core.PApplet;
import processing.core.PConstants;

import java.awt.Dimension;
import java.awt.event.KeyListener;
//import java.util.ArrayList;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;


public class Main extends PApplet{
    //private ArrayList<Integer> TimeList = new ArrayList<>();
    private int width;
    private int height;
    private Timer timer;
    private Scramble scramble;
    private TimeList timeList;
    private HelpWindowandButton helpWindowandButton;
    private InspectionButton inspectionButton;


    public Main(int width){
       this.width = width;
       this.height = 4 * width / 5;
       this.timeList = new TimeList(this,this.width/2, 5 * this.height/8, 3*this.height/40, this.width - (3*this.height/40),0,3*this.height/40,this.width-(3*this.height/20),0,8 * this.width / 25, 2 * this.width / 25, 47 * this.width / 50,3 * this.width / 20, 3 * this.height / 40, this.width - (3 * this.height /20),3 * this.height / 40);
       this.timer = new Timer(this,this.width/2,this.height/2, true);
       this.scramble = new Scramble(this,this.width/2,this.height/32,Scramble.Puzzle.THREE,0,3 * this.height / 40,this.height/10,this.height/40);
       this.helpWindowandButton = new HelpWindowandButton(0,0,3*this.height/40,this);
       this.inspectionButton = new InspectionButton(3*this.height/40,0,3*this.height/40,this);
       
    }
    @Override
    public void settings(){
        size(width,height);
    }

    @Override
    public void setup(){
        textAlign(PConstants.CENTER, PConstants.CENTER);
    }

    @Override
    public void draw(){
        //textAlign(PConstants.CENTER, PConstants.CENTER);
        background(51);
        if(!helpWindowandButton.getHelpBool()) {
            if(timer.getStatus() == 0) {
                scramble.render();
                inspectionButton.render();
                timeList.render();
                helpWindowandButton.render();
            }
            timer.render();
        }else {
            helpWindowandButton.render();
        }
    }
    @Override
    public void keyPressed() {
        if(!helpWindowandButton.getHelpBool() && !timeList.getAddTimeBool()){
            if(keyCode == 32){
                if((timer.getStatus() % 2) == 0) {
                    timer.statusUpdate();
                }
            }
            if((timer.getStatus() == 5) || (timer.getStatus() == 3 && !timer.getInspectionBool())){
                timer.setText(timer.returnText(timer.returnTime(System.currentTimeMillis(),timer.getStartTime())));
                timer.statusUpdate();
            }
        }
        if(timeList.getAddTimeBool()){
            if(keyCode >= 48 && keyCode <= 57 || key == '.' || key == ':'){ //0 to 9 and period
                textSize(height / 30);
                fill(0,0,0);
                timeList.getAddTimeBox().addChar(key);
            }else if(keyCode == 8) { //Backspace
                timeList.getAddTimeBox().delChar();
            }else if(keyCode == PConstants.ENTER || keyCode == PConstants.RETURN) { //Enter
                timeList.addTime(new Time(timeList.getAddTimeBox().getText(), timer.getPenalty(),scramble.getScramble(),this));
                timeList.flipAddBool();
            }

        }
        if(key==CODED) {
        	if(keyCode==UP) {
        		timeList.decStartIndex();
        		timeList.render();
        	}else if(keyCode==DOWN) {
        		timeList.incStartIndex();
        		timeList.render();
        	}
        }
    }
    public void keyReleased() {
        if(!helpWindowandButton.getHelpBool()){
            if(!timeList.getAddTimeBool()) {
                if (keyCode == 32) {
                    if ((timer.getStatus() % 2) == 1)
                        timer.statusUpdate();
                    if (timer.getStatus() == 0) {
                        timeList.addTime(new Time(timer.getText(), timer.getPenalty(), scramble.getScramble(),this));
                        //System.out.println(Time.returnLine(Time.GetDoubleFromTime(timer.getText()),timer.getPenalty(),scramble.getScramble()));
                        scramble.makeScramble();
                    }
                }
            }
        }
    }
 
    public void mousePressed(){
        if(inspectionButton.isUnderMouse()){
            if(timer.getStatus() == 0) {
                inspectionButton.setRGB(0,255,255);
                inspectionButton.render();
                timer.flipInspection();
                inspectionButton.flipInspectionButtonBool();
            }
        }else if(helpWindowandButton.isUnderMouse()){
            timer.reset();
            helpWindowandButton.flipHelp();
        }else if(timeList.getClearTimesButton().isUnderMouse()){
            timer.reset();
            timeList.clearTimes();
            timeList.getClearTimesButton().setRGB(0,255,255);
            timeList.render();
        }else if(timeList.getAddTimeButton().isUnderMouse()){
            timeList.getAddTimeButton().setRGB(0,255,255);
            timeList.flipAddBool();
            timeList.render();
        }else if(timeList.getDelLastTimeButton().isUnderMouse()){
            timeList.getDelLastTimeButton().setRGB(0,255,255);
            timeList.delLastTime();
            timeList.render();
        }else if(scramble.getScrambleTypeButton().isUnderMouse()){
            scramble.getScrambleTypeButton().setRGB(0,255,255);
            scramble.incrementScrambleType();
            scramble.makeScramble();
            scramble.render();
        }

    }
  


    public static void main(String[] args) {
    	Main ClicksIncTimer = new Main( 1250);
    	ClicksIncTimer.timeList.read();
		//DrawingSurface drawing = new DrawingSurface(20);
		PApplet.runSketch(new String[]{""}, ClicksIncTimer);
		PSurfaceAWT surf = (PSurfaceAWT) ClicksIncTimer.getSurface();
		PSurfaceAWT.SmoothCanvas canvas = (PSurfaceAWT.SmoothCanvas) surf.getNative();
		JFrame window = (JFrame)canvas.getFrame();
		
		window.setSize(1250,1000);
		window.setMinimumSize(new Dimension(100,100));
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(true);

		window.setVisible(true);
		
		window.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
            	ClicksIncTimer.timeList.write();
                ClicksIncTimer.timeList.closeIO();
                System.exit(0);
            }
        });
		

    }
}
/*  TODO
* update help window
* Make sure that ClearTimeButton and AddTimeButton flash cyan for an instant when pressed
* Add functionality to AddTimeButton (User Input is hard)
*
*
*
*
*
* Watch the Lx Rx Lx case for scrambling <- it's sneaky

v1,0
    - Basic functionality added
v1.1 & 1.2
    - Better
    - Inspection added
    - Inspection button added.
v1.3
    - Added help window, inspection, more flexible initialization of main.
    - Timer stops the instant space is pressed rather than released now
    - Hundreths display with stability and minute: second display was added
    - Fixed the R(x) L(x) R(x) case for scrambling || 1.4: NOPE
v1.4
    - Fixed the inspection space bar bugs
    - Added average support? + time list works
    - Penalties picked up in inspection now count
    - Clearing time list added

 */