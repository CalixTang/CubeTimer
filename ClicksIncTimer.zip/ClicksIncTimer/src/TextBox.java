
import processing.core.PApplet;
import processing.core.PConstants;

public class TextBox {
    private float x;
    private float y;
    private float width;
    private float height;
    private PApplet sketch;
    private String text;
    private boolean isVisible;

    public TextBox(float x, float y, float width, float height, PApplet sketch, boolean isVisible) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.sketch = sketch;
        this.isVisible = isVisible;
        text = "";
    }

    public boolean isVisible(){
        return isVisible;
    }
    public void flipVisibility(){
        isVisible = !isVisible;
        text = "";
    }
    public void addChar(char c){
        text += Character.toString(c);
    }
    public void addChar(String s){
        text += s;
    }
    public void delChar(){
        if(!text.equals("")) {
            text = text.substring(0, text.length() - 1);
        }
    }
    public String getText(){
        return text;
    }

    public void render(){
        if(isVisible){
            sketch.fill(255,255,255);
            //The rect will be centered at X,Y. It will have width width and height height
            sketch.rectMode(PConstants.RADIUS);
            sketch.rect(x,y, width/2, height/2);
            sketch.fill(0,0,0);
            sketch.textSize(height);
            sketch.text(text, x,y);
            sketch.rectMode(PConstants.CORNER);
            sketch.fill(255);
        }
    }
}
