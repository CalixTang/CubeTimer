
import processing.core.PApplet;

public class Time {
    private String time;
    private String scramble;
    public enum Penalty{OK, P2, DNF};//0 ok 1 +2 2 DNF
    private short pen; //0 1 2
    private double timeDouble;
    private PApplet sketch;
    Penalty penalty;

    public static double GetDoubleFromTime(String time){ //1:20.40 -> 80.40
        try{
            return Double.parseDouble(time);
        }catch(NumberFormatException e){
            //we can try to assume x:xx.xx format?
            return 60 * Double.parseDouble(time.substring(0,time.indexOf(':'))) + Double.parseDouble(time.substring(time.indexOf(':')+1));
        }
    }
    public static String GetFormattedTime(double time){ //80.40 -> 1:20.40
        if(time > 60){
            return Integer.toString((int)time / 60) + ":" + Timer.PadTime(Timer.TrimTime(Double.toString(time % 60)));
        }
        return Double.toString(time);
    }
    
    public static String returnLine(double time, short p, String scramble) {
    	return  GetFormattedTime(time) + ", " + p + ", " + scramble;
    }

    /*
    public Time(String time, Penalty penalty, String scramble, PApplet sketch) {
        this.time = time;
        this.penalty = penalty;
        this.scramble = scramble;
        this.timeDouble = GetDoubleFromTime(time);
        this.sketch = sketch;
    }
    */
    public Time(String time, short pen, String scramble, PApplet sketch) {
        this.time = time;
        this.pen = pen;
        this.scramble = scramble;
        if(time.contains(":")) {
        	this.timeDouble = GetDoubleFromTime(time);
        }else {
        	this.timeDouble = Double.parseDouble(time);
        }
        this.sketch = sketch;
    }
    public Time(double time, short pen, String scramble, PApplet sketch) {
        this.time = GetFormattedTime(time);
        this.pen = pen;
        this.scramble = scramble;
        this.timeDouble = time;
        this.sketch = sketch;
    }
    public void reFormat(){
        switch(pen){
            case 1:
                time = Double.toString(Double.parseDouble(time) + 2);
                break;
            case 2:
                time = "DNF";
        }
        time = GetFormattedTime(GetDoubleFromTime(time));

    }

    
    public double getTimeDouble(){
        return timeDouble;
    }
    public String getTime() {
        return time;
    }

    public short getPenalty() {
        return pen;
    }

    public String getScramble() {
        return scramble;
    }
    private boolean isUnderMouse(float x, float y){
        return ((sketch.mouseX >= x - sketch.width / 20) && (sketch.mouseX <= x + sketch.width / 20) && (sketch.mouseY >= y - sketch.width / 80) && (sketch.mouseY <= y + sketch.width / 80));
    }

    public void render(float x, float y){
        sketch.fill(255,255,255);
        sketch.text(time, x , y);
        if(isUnderMouse(x,y)){
            //Fill later
        }
    }
}
