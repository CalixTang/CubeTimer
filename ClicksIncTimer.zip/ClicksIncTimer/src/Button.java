
import processing.core.PApplet;

public class Button {
    //square Button
    private float x;
    private float y;
    private int R;
    private int G;
    private int B;
    private float width;
    private float height;
    private PApplet sketch;
    private boolean isVisible;
    private boolean isPressed;

    public Button(float x, float y, float buttonSides, PApplet sketch, boolean isVisible){
    	this.x = x;
        this.y = y;
        this.width = this.height = buttonSides;
        this.sketch = sketch;
        this.isVisible = isVisible;
        R = G = B = 255;
    }
    public Button(float x, float y, float buttonWidth, float buttonHeight, PApplet sketch, boolean isVisible){
    	this.x = x;
        this.y = y;
        this.width = buttonWidth;
        this.height = buttonHeight;
        this.sketch = sketch;
        this.isVisible = isVisible;
        R = G = B = 255;
    }
    public boolean isUnderMouse(){
        return (sketch.mouseX >= this.x && sketch.mouseY >= this.y && sketch.mouseX <= this.x+this.width && sketch.mouseY <= this.y + this.height);
    }
    public void setRGB(int R, int G, int B){
        this.R = R;
        this.G = G;
        this.B = B;
    }
    public void render(){
        if(isVisible) {
            sketch.fill(R,G,B);
            sketch.rect(x, y, width, height, (width + height) / 2 / 10.7f);
            renderExtras();
            setRGB(255,255,255);
            sketch.fill(255,255,255);
        }
    }
    public void renderExtras(){
        //Overridden method in subclasses so they can do more than draw an empty button
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }
    public float getHeight(){
        return height;
    }

    public PApplet getSketch() {
        return sketch;
    }

    public boolean isVisible() {
        return isVisible;
    }

    public void setVisible(boolean visible) {
        isVisible = visible;
    }
    public boolean getPressed(){
        return isPressed;
    }
    public void flipPressed(){
        isPressed = !isPressed;
    }
}
