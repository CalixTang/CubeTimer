import processing.core.PApplet;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.LinkedList;
public class TimeList {
    public static final String DEFAULT_TIME = "DNF";
    private static String[] avgFiveStringArray = new String[5];
    private LinkedList<Time> timeList = new LinkedList<Time>();
    private PApplet sketch;
    private float x;
    private float y;
    //X and Y are for Current Ao5, mo3, etc
    private Button clearTimesButton;
    private Button addTimeButton;
    private Button delLastTimeButton;
    private boolean addTimeBool; //this is true if the user is inputting a time and false otherwise.
    private TextBox addTimeBox;
    private float timeListX;
    private float timeListY;
    private int startIndex;
    public static final int SEEABLE_TIMES = 12;
    public BufferedReader reader;
    public PrintWriter writer;

    public TimeList(PApplet sketch, float x, float y,float clearButtonSides, float clearButtonX, float clearButtonY,float addButtonSides, float addButtonX, float addButtonY, float addTimeBoxWidth, float addTimeBoxHeight,float timeListX, float timeListY, float delButtonSides, float delButtonX, float delButtonY){
        this.sketch = sketch;
        this.x = x;
        this.y = y;
        this.clearTimesButton = new Button(clearButtonX,clearButtonY,clearButtonSides,sketch,true);
        this.addTimeButton = new Button(addButtonX,addButtonY,addButtonSides,sketch,true);
        this.delLastTimeButton = new Button(delButtonX,delButtonY,delButtonSides,sketch,true);
        addTimeBool = false;
        addTimeBox = new TextBox(x,y,addTimeBoxWidth, addTimeBoxHeight, sketch, addTimeBool);
        this.timeListX = timeListX;
        this.timeListY = timeListY;
        startIndex = 0;
        try {
			reader = new BufferedReader(new FileReader("data//timelist.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("timelist.txt not found in the data folder. Plesae create it.");
		} catch (IOException e) {
			System.out.println("Something bad has occured when doing I/O.");
		}
    }
    public void read() {
    	try {
    		String line = "";
        	while((line = reader.readLine())!=null) {
        		String timeString = line.substring(0,line.indexOf(','));
        		line = line.substring(line.indexOf(',')+2);
        		short pen = Short.parseShort(line.substring(0,line.indexOf(',')));
        		line = line.substring(line.indexOf(',')+2);
        		String scramble = line.substring(0);
        		System.out.println(timeString + pen + scramble);
        		this.addTime(new Time(timeString,pen,scramble,sketch));
        	}
    	}catch(IOException e) {
    		System.out.println("Error occured writing times.");
    	}
    	
    }

	public void write() {
		try {
		writer = new PrintWriter(new BufferedWriter(new FileWriter("data//timelist.txt")));
		}catch(IOException e) {
			System.out.println("Problem writing to file in TimeList.");
		}
		while (!this.timeList.isEmpty()) {
			Time t = timeList.getFirst();
			timeList.remove(0);
			writer.println(Time.returnLine(t.getTimeDouble(), t.getPenalty(), t.getScramble()));
		}
	}

    public void closeIO() {
    	try {
    		reader.close();
    		writer.close();
    	}catch(IOException e) {
    		System.out.println("Error has occured closing IO streams in TimeList.");
    	}
    }
    private static String[] SortArray(String[] data) {
        String tempString;
        for(int i = 0; i < data.length-1; i++){
            for(int k = i+1; k < data.length;k++){
                if(data[i].compareToIgnoreCase(data[k])>0){
                    tempString = data[k];
                    data[k] = data[i];
                    data[i] = tempString;
                }
            }
        }
        return data;
    }

    public TextBox getAddTimeBox() {
        return addTimeBox;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public boolean getAddTimeBool(){
        return addTimeBool;
    }
    public void flipAddBool(){
        addTimeBool = !addTimeBool;
        addTimeBox.flipVisibility();
    }
    public Button getClearTimesButton(){
        return clearTimesButton;
    }
    public Button getAddTimeButton(){
        return addTimeButton;
    }
    public Button getDelLastTimeButton(){
        return delLastTimeButton;
    }
    public void addTime(Time time) {
        time.reFormat();
        timeList.add(time);
    }
    public void delLastTime(){
        if(timeList.size()>=1)
            timeList.removeLast();
    }
    public void delTime(int index){
        if(index >= 0 && index <timeList.size())
            timeList.remove(index);
    }
    public void clearTimes(){
        timeList.clear();
    }

    //BELOW ARE THE STATS METHODS
    //avgFive can be called anytime as it will return "-" when the timeList is less than five strings long.
    public String avgFive() {
        if (timeList.size() >= 5) {
            for (int i = timeList.size(); i >= timeList.size() - 4; i--) {
                avgFiveStringArray[timeList.size() - i] = timeList.get(i - 1).getTime();
            }
            avgFiveStringArray = SortArray(avgFiveStringArray);
            try {
                return Timer.TrimTime(Double.toString((Double.parseDouble(avgFiveStringArray[1]) + Double.parseDouble(avgFiveStringArray[2]) + Double.parseDouble(avgFiveStringArray[3])) / 3.));
                //oh my this is a frightening line of code
                //trimTime: 2 decimal place precision formatting
                //we have to convert from Strings to doubles to get an arithmetic mean, and then convert it back to a String for the return type.
                //Aside from that we have our sorted array of five and then just take the middle three and then get their mean.
            } catch (NumberFormatException e) {
                return DEFAULT_TIME;
            }
        }
        return "-";
    }
    public String sessionMean(){
        if(timeList.size() > 0){
            double sum = 0.;
            int total = 0;
            for(Time t : timeList) {
                try {
                    sum += t.getTimeDouble();
                    total++;
                }catch(NumberFormatException e){

                }catch(NullPointerException e){

                }
            }
            return Timer.TrimTime(Time.GetFormattedTime(sum / total));
        }
        return "-";
    }
    
    public int incStartIndex() {
    	if(timeList.size()>SEEABLE_TIMES) {
    		if(startIndex + SEEABLE_TIMES > timeList.size()-1) {
        		return -1;
        	}else {
        		startIndex++;
        		return 0;
        	}
    	}
    	return -1;
    }
    public int decStartIndex() {
    	if(timeList.size()>SEEABLE_TIMES) {
    		if(startIndex <= 0) {
        		return -1;
        	}else {
        		startIndex--;
        		return 0;
        	}
    	}
    	return -1;
    }
    public void render() {
        sketch.fill(255, 255, 255);
        sketch.textSize(3 * sketch.width / 100);
        sketch.text("Current ao5: " + avgFive(), x, y);
        sketch.text("Session Mean: " + sessionMean(), x, y + sketch.width/16);
        sketch.text("TIMES",timeListX,timeListY);
        if(timeList.size()<=SEEABLE_TIMES) { //Less than or equal to 12 elements 
        	for(int i = 0; i < timeList.size(); i++) {
        		timeList.get(i).render(timeListX, timeListY +((i+2)*(sketch.width/40)));
        	}
        }else {
        	for(int i = 0; i < SEEABLE_TIMES; i++) {
        		timeList.get(i+startIndex).render(timeListX,timeListY + ((i+2) * (sketch.width / 40)));
        	}
        	if(startIndex>0) {
        		sketch.textSize(sketch.width/50);
        		sketch.text( startIndex + " more times", timeListX,timeListY + (sketch.width/40));
        	}
        	if(timeList.size()-SEEABLE_TIMES-startIndex > 0) {
        		sketch.textSize(sketch.width/50);
            	sketch.text(timeList.size()-SEEABLE_TIMES-startIndex + " more times", timeListX, timeListY + (SEEABLE_TIMES + 3)*(sketch.width/40));
        	}
        }
        clearTimesButton.render();
        addTimeButton.render();
        delLastTimeButton.render();
        sketch.fill(255, 0, 0);
        sketch.quad(clearTimesButton.getX() + (5 * clearTimesButton.getWidth() / 16), clearTimesButton.getY() + clearTimesButton.getWidth() / 4, clearTimesButton.getX() + (clearTimesButton.getWidth() / 4), clearTimesButton.getY() + (5 * clearTimesButton.getWidth() / 16), clearTimesButton.getX() + (11 * clearTimesButton.getWidth() / 16), clearTimesButton.getY() + (3 * clearTimesButton.getWidth() / 4), clearTimesButton.getX() + (3 * clearTimesButton.getWidth() / 4), clearTimesButton.getY() + (11 * clearTimesButton.getWidth() / 16));
        sketch.quad(clearTimesButton.getX() + (11 * clearTimesButton.getWidth() / 16), clearTimesButton.getY() + clearTimesButton.getWidth() / 4, clearTimesButton.getX() + (3 * clearTimesButton.getWidth() / 4), clearTimesButton.getY() + (5 * clearTimesButton.getWidth() / 16), clearTimesButton.getX() + (5 * clearTimesButton.getWidth() / 16), clearTimesButton.getY() + (3 * clearTimesButton.getWidth() / 4), clearTimesButton.getX() + (clearTimesButton.getWidth() / 4), clearTimesButton.getY() + (11 * clearTimesButton.getWidth() / 16));
        sketch.fill(0, 0, 0);
        sketch.textSize(clearTimesButton.getWidth() / 5);
        sketch.text("CLEAR", clearTimesButton.getX() + clearTimesButton.getWidth() / 2, clearTimesButton.getY() + clearTimesButton.getWidth() / 8);
        sketch.text("TIMES", clearTimesButton.getX() + clearTimesButton.getWidth() / 2, clearTimesButton.getY() + (7 * clearTimesButton.getWidth() / 8));
        sketch.fill(255, 255, 255);

        sketch.fill(0, 255, 0);
        sketch.rect(addTimeButton.getX() + (3 * addTimeButton.getWidth() / 8), addTimeButton.getY() + (addTimeButton.getWidth() / 4), addTimeButton.getWidth() / 4, addTimeButton.getWidth() / 2);
        sketch.rect(addTimeButton.getX() + (addTimeButton.getWidth() / 4), addTimeButton.getY() + (3 * addTimeButton.getWidth() / 8), addTimeButton.getWidth() / 2, addTimeButton.getWidth() / 4);
        sketch.fill(0, 0, 0);
        sketch.textSize(addTimeButton.getWidth() / 5);
        sketch.text("ADD", addTimeButton.getX() + addTimeButton.getWidth() / 2, addTimeButton.getY() + addTimeButton.getWidth() / 8);
        sketch.text("TIME", addTimeButton.getX() + addTimeButton.getWidth() / 2, addTimeButton.getY() + (7 * addTimeButton.getWidth() / 8));

        sketch.fill(255,0,0);
        sketch.rect(delLastTimeButton.getX() + (delLastTimeButton.getWidth() / 4), delLastTimeButton.getY() + (3 * delLastTimeButton.getWidth() / 8), delLastTimeButton.getWidth() / 2, delLastTimeButton.getWidth() / 4);
        sketch.textSize(delLastTimeButton.getWidth() / 5);
        sketch.fill(0,0,0);
        sketch.text("DELETE", delLastTimeButton.getX() + delLastTimeButton.getWidth() / 2, delLastTimeButton.getY() + delLastTimeButton.getWidth() / 8);
        sketch.text("LAST", delLastTimeButton.getX() + delLastTimeButton.getWidth() / 2, delLastTimeButton.getY() + (7 * delLastTimeButton.getWidth() / 8));

        addTimeBox.render();
    }
}